from django.db import models

# Create your models here.

class Employee(models.Model):

    name=models.CharField(max_length=30)
    age=models.PositiveIntegerField()
    salary=models.PositiveBigIntegerField()
    designation=models.CharField(max_length=30)
    email=models.EmailField()
    phone=models.PositiveBigIntegerField()
    place=models.CharField(max_length=50,null=True)

    def __str__(self): #for sting representation

        return self.name


# python manage.py makemigrations  -  to conver to query language
# python manage.py migrate - to impliment in database

# create new django project
# filim world

# schema: Filim
# attributes:title,year


class Work(models.Model):

    title=models.CharField(max_length=100)
    description=models.CharField(max_length=100)
    start_date=models.DateField(null=True)
    end_date=models.DateField(null=True)
    status_option=(
        ("create","create"),
        ("wip","wip"),
        ("completed","completed"),
        ("due","deu"),
    )
    status=models.CharField(max_length=50,choices=status_option,default="created")


