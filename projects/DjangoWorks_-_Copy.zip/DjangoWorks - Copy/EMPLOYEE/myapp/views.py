from django.shortcuts import render
from django.views.generic import View
from myapp.models import Employee,Work
from myapp.forms import WorkForm
from django.shortcuts import redirect

# Create your views here.

# url:localhost:8000/employees/all/
# mrthod:get

class EmployeeListView(View):

    def get(self,request,*args,**kwargs):

        qs=Employee.objects.all()

        return render(request,'employee_list.html',{'employees':qs})

  


# cred

# 


class WorkCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance=WorkForm()

        return render(request,"work_add.html",{"form":form_instance})

    def post(self,request,*args,**kwargs):

        form_instance=WorkForm(request.POST)

        if form_instance.is_valid():

            data=form_instance.cleaned_data

            Work.objects.create(**data)

            return redirect('work-all')

        return render(request,'work_add.html')    

# url: localhost:8000/work/all/

class WorkListView(View):

    def get(self,request,*args,**kwargs):

        qs=Work.objects.all()

        return render(request,"work_list.html",{'works':qs})
    
class WorkUpdateView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        work_object=Work.objects.get(id=id)

        data={
            "title":work_object.title,
            "description":work_object.description,
            "start_date":work_object.start_date,
            "end_date":work_object.end_date,
            "status":work_object.status,
        }

        form_instance=WorkForm(initial=data)

        return render(request,"work_update.html",{'form':form_instance}) 
       
    def post(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        form_instance=WorkForm(request.POST)

        if form_instance.is_valid():

            data = form_instance.cleaned_data

            Work.objects.filter(id=id).update(**data)

            return redirect("work_all")
        else:
            return render(request,"work_edit.html",{'form':form_instance})

class WorkDeleteView(View):

    def get(self,request,*args,**kwargs):

        id= kwargs.get("pk")

        Work.objects.get(id=id).delete()

        return redirect("work_all")
