from django.db import models

# Create your models here.
class Filim(models.Model):

    title=models.CharField(max_length=50)
    year=models.PositiveIntegerField()
    genre=models.CharField(max_length=50)
    direector=models.CharField(max_length=50)
    tags=models.CharField(max_length=50)
    songs_count=models.PositiveIntegerField()
    language=models.CharField(max_length=50)
    is_trending=models.BooleanField()

# python manage.py makemigrations  -  to create query file
# python manage.py migrate - to exicute in query file