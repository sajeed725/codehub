from django.shortcuts import render,redirect

from django.urls import reverse,reverse_lazy

from django.views.generic import View,TemplateView,UpdateView,CreateView

from store.forms import SignUpForm,LoginForm,UserProfileForm,ProjectForm

from django.contrib.auth import authenticate,login

from store.models import UserProfile,Project

# Create your views here.

class SignUPView(View):

    def get(self,request,*args,**kwargs):

        form_instance=SignUpForm()

        return render(request,"store/register.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=SignUpForm(request.POST)

        if form_instance.is_valid():

            form_instance.save()

            return redirect("login")
        else:
            return render(request,"store/register.html",{"form":form_instance})




class LoginView(View):

    def get(self,request,*args,**kwargs):

        form_instance=LoginForm()

        return render(request,"store/login.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=LoginForm(request.POST)

        if form_instance.is_valid():

            data=form_instance.cleaned_data

            user_object=authenticate(request,**data)

            if user_object:

                login(request,user_object)

                return redirect("index")
            
        return render (request,"store/login.html",{"form":form_instance})  

class IndexView(TemplateView):

    template_name="store/index.html"


class UserProfileUpdateView(UpdateView):

    model=UserProfile

    form_class=UserProfileForm

    template_name="store/profile_edit.html"

    # def get_success_url(self):

    #     return reverse("index")
    
    success_url=reverse_lazy("index")
    

 
class ProjectCreatView(CreateView):

    model=Project

    form_class=ProjectForm

    template_name="store/project_add.html"

    success_url=reverse_lazy("index")

    
              