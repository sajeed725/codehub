from django.shortcuts import render

# Create your views here.

from django.views.generic import View

class HelloWorldView(View):
    def get(self,request,*args,**kwargs):

        return render(request,"hello_world.html")


class GoodMorningView(View):
    def get(self,request,*args,**kwargs):

        return render(request,"goodmorning.html")

class GoodAfternoonView(View):
    def get(self,request,*args,**kwargs):


        return render(request,"good_afternoon.html")


class SelfIntroView(View):
    def get(self,request,*args,**kwargs):

        data={"name":"sajeed","course":"django","age":"21","gender":"male"}
        return render(request,"self_intro.html",data)

class VehicleDetailsView(View):
    def get(self,request,*args,**kwargs):
        data={"name":"fz-s","model":"2012","brand":"yamaha","fuel":"petrol"}
        return render(request,"vehicle_details.html",data)
class MobileDetails(View):
    def get(self,request,*args,**kwargs):
        data={"name":"s24 ultra","os":"android","brand":"samsung","color":"white"}
        return render(request,"mobile_details.html",data)

class LaptopDetailsView(View):
    def get(self,request,*args,**kwargs):
        data={"name":"victus","os":"windows","brand":"hp","color":"black"}
        return render(request,"laptop_details.html",data)

class WatchDetailsView(View):
    def get(self,request,*args,**kwargs):
        data={"name":"rolex","color":"black","price":"1 lak"}
        return render(request,"watch_details.html",data) 

class HeadphoneDetailsview(View):
    def get(self,request,*args,**kwargs):
        data={"name":"boathead","type":"bluetooth","color":"red"}
        return render(request,"headphone_details")
