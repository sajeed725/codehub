from django.shortcuts import render
from django.views.generic import View

# Create your views here.

# addition
# url:localhost:8000/add/
# method:
    #  get:a template with addition form
    #  pot:

class AdditionView(View):
    def get(self,request,*args,**kwargs):
        return render(request,'addition.html')    

    def post(self,request,*args,**kwargs):

        num1=request.POST.get("num1")
        num2=request.POST.get("num2")

        result=int(num1)+int(num2)
        print(result)

        data={"result":result}

        return render(request,'addition.html',data)    

class Bmiview(View):
    def get(self,request,*args,**kwargs):
        return render(request,'bmi.html')    
    def post(self,request,*args,**kwargs):

        height_in_cm=request.POST.get('height_in_cm')
        weight_in_kg=request.POST.get('weight_in_kg')
        height_in_meter=int(height_in_cm)/100
        bmi=int(weight_in_kg)/int(height_in_meter**2)
        print(bmi)
        data={"bmi":bmi}
        return render(request,"bmi.html",data)

class CalorieCalculateView(View):
    def get(self,request,*args,**kwargs):
        return render(request,"calorie.html")
    def post(self,request,*args,**kwargs):

        weight=request.POST.get("weightBox")    

        height=request.POST.get("heightBox")  

        age=request.POST.get("ageBox") 

        gender=request.POST.get("genderBox")  

        activity=request.POST.get("activityBox")

        print(f"a={age},w={weight},h={height},g={gender},act={activity}")

        if gender=="male":
             BMR=10*int(weight) + 6.25*int(height) - 5*int(age) +5
        else:
             BMR=10*int(weight) + 6.25*int(height) - 5*int(age) -161   

        CALORIE=BMR*float(activity)   
        print(f"calorie={CALORIE}")  
        data={"calorie":CALORIE}  

        return render(request,"calorie.html",data)

class EmiCalculatorView(View):
    def get(self,request,*args,**kwargs):
        return render(request,"emi.html")
    def post(self,request,*args,**kwargs):
        amount=request.POST.get("amountBox")
        interest=request.POST.get("interestBox")
        duration=request.POST.get("durationBox")

        print(f"a={amount},i={interest},d={duration}")
        P=int(amount)
        R=int(interest)
        N=int(duration)
        
        EMI = (P * R * (1+R) **N)/ ((1+R) ** (N-1))
        # EMI=int(amount*interest*(1+interest)**duration)/int((1+interest)**int(duration-1))
        total_amount=(EMI*N)
        data={'emi':EMI,'total_amount':total_amount}
        return render(request,"emi.html",data)
            
class IndexView(View):

    def get(self,request,*args,**kwargs):
        return render(request,'index.html')            
class WeightView(View):
    def get (self,request,*args,**kwargs):
        return render(request,'weight.html')

    def post(self,request,*args,**kwargs):
        height=request.POST.get('heightBox')   
        weight=request.POST.get('weightBox') 
        gender=request.POST.get('genderBox')
        age=request.POST.get('ageBox')
        activity=request.POST.get('activityBox')
        gorl=request.POST.get('g/lBox')
        target=request.POST.get('targetBox')
        days=request.POST.get('daysBox')
        if gorl=="gain":
            weight+=target
        else:
            weight-=target

        
        if gender=="male":
             
              BMR=10*int(weight) + 6.25*int(height) - 5*int(age) +5
             
        else:
              BMR=10*int(weight) + 6.25*int(height) - 5*int(age) -161 

        CALORIE=BMR*float(activity)   
        print(f"calorie={CALORIE}")  
        data={"calorie":CALORIE}        

        return render(request,'weght.html')