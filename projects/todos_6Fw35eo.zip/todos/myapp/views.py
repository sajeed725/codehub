from django.shortcuts import render,redirect

from django.views.generic import View

from myapp.forms import TodoForm,RegistrationForm,LoginForm

from django.contrib.auth import authenticate,login,logout

from myapp.models import Todo

from django.contrib import messages

from myapp.decorators import signin_required

from django.utils.decorators import method_decorator



# Create your views here.
@method_decorator(signin_required,name="dispatch")
class TodoCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance=TodoForm(user=request.user)

        qs=Todo.objects.filter(owner=request.user)

        return render(request,"todo_add.html",{"form":form_instance,"qs":qs})
    
    def post(self,request,*args,**kwargs):

        form_instance=TodoForm(request.POST,user=request.user)

        if form_instance.is_valid():

            # form_instance.save()
            data=form_instance.cleaned_data

            Todo.objects.create(**data,owner=request.user)

            return redirect("todo-add")
        
        else:

             return render(request,"todo_add.html",{"form":form_instance})
        

class SignUpView(View):

    def get(self,request,*args,**kwargs):

        form_instance=RegistrationForm()

        return render(request,"register.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=RegistrationForm(request.POST)

        if form_instance.is_valid():

            form_instance.save()

            print("register successfully...")

            messages.success(request,"account created successfully")

            return redirect("signin")

        else:

            print("registration failed")

            messages.error(request,"account creation failed")

            return render(request,"register.html",{"form":form_instance})
        
    
class SignInView(View):

    def get(self,request,*args,**kwargs):

        form_instance=LoginForm()

        return render(request,"login.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=LoginForm(request.POST)

        if form_instance.is_valid():
             
             data=form_instance.changed_data

            #  u_name=data.get('username')

            #  pwd=data.get('password')

             user_obj=authenticate(request,**form_instance.cleaned_data)
     
             if user_obj:
     
                 login(request,user_obj)
     
                 return redirect("todo-add")
            
        return render(request,"login.html",{"form":form_instance})
    
@method_decorator(signin_required,name="dispatch")
class TodoUpdateView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        todo_obj=Todo.objects.get(id=id)

        form_instance=TodoForm(instance=todo_obj,user=request.user)

        return render(request,"todo_edit.html",{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        todo_obj=Todo.objects.get(id=id)

        form_instance=TodoForm(request.POST,instance=todo_obj,user=request.user)

        if form_instance.is_valid():

            form_instance.save()

            return redirect("todo-add")
        
        else:

            return render(request,"todo_edit.html",{"form":form_instance})
        
@method_decorator(signin_required,name="dispatch")        
class TodoDeleteView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        Todo.objects.get(id=id).delete()

        return redirect("todo-add")
    
@method_decorator(signin_required,name="dispatch")    
class SignOutView(View):

    def get(self,request,*args,**kwargs):

        logout(request)

        return redirect("signin")


